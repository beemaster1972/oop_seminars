package decorator;

public interface WashingProgram {

  void executeProgram();
}