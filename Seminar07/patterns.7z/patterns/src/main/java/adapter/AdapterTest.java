package adapter;

public class AdapterTest {

  public static void main(String[] args) {

  }

}
