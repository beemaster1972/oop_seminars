package adapter;

public interface DataObject {

  double getValue(String fieldName);
}