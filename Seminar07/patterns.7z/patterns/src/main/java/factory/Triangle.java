package factory;

import java.awt.Point;

public class Triangle implements Figure {

  public Triangle(Point a, Point b, Point c) {

  }

  @Override
  public double calculatePerimeter() {
    return 0;
  }

  @Override
  public double calculateSquare() {
    return 0;
  }

  @Override
  public double getWidth() {
    return 0;
  }

  @Override
  public double getHeight() {
    return 0;
  }
}
