package factory;

import java.awt.Point;
import java.util.List;

public class Hexagon implements Figure {

  public Hexagon(List<Point> points) {

  }

  @Override
  public double calculatePerimeter() {
    return 0;
  }

  @Override
  public double calculateSquare() {
    return 0;
  }

  @Override
  public double getWidth() {
    return 0;
  }

  @Override
  public double getHeight() {
    return 0;
  }
}
