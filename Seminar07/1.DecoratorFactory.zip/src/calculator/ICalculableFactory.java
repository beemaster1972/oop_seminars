package calculator;

public interface ICalculableFactory {
    Calculable create(int primaryArg);
}
