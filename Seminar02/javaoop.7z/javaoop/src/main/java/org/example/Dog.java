package org.example;

public class Dog extends Animal{
    @Override
    public void voice() {

    }
}
